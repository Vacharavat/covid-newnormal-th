export default {
  primary: "#436BFC",
  secondary: "#B7B7FF", // light purple
  gray:'#3A3A3C',
  green:'#34C759',
  skyblue:'#5AC8FA',
  lightblue:'#7B98FF',
  red:'#FF313A',
  purple:'#7777FF',
  darkpurple:'#473F97',
  white:'#FFFFFF',
  lightgray:'rgb(229,229,234)'

};