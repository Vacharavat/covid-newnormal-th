export * from './Home/HomeScreen'
export * from './Home/HomeScreenDetail'
export * from './Home/SymptompsScreenDetail'
export * from './Home/PreventionsScreenDetail'

export * from './Map/MapsScreen'
export * from './Map/ReportScreen'
export * from './Map/NewScreen'


export * from './NewNormal/NewNormalScreen'
export * from './NewNormal/NewNormalScreenDetail'
export * from './NewNormal/NewNormalScreenDetail2'
export * from './NewNormal/NewNormalScreenDetail3'

export * from './Info/InfoScreen'
export * from './Info/InfoScreenDetail'
export * from './Info/InfoScreenDetail2'
export * from './Info/InfoScreenDetail3'